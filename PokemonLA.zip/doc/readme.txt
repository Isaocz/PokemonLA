1. 配置 unityyamlmerge 
将 .gitconfig copy 到工程根目录，并将 UnityYAMLMerge.exe 的路径修改为正确的路径。