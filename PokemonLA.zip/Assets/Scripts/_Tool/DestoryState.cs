using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestoryState : MonoBehaviour
{
    public void DestorySelf()
    {
        Destroy(gameObject);
    }
}
