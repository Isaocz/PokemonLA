using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConstantRoom
{
    public static int ROOM_INNER_WIDTH = 24;
    public static int ROOM_INNER_HIGHT = 14;
}
