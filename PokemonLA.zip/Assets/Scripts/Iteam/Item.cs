using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public Sprite StoreImage;
    public int Price;
    public string ItemDescribe;
    public string ItemName;
    public int ItemTag;
    public int[] ItemTypeTag;
    //Tag1: ����
}
