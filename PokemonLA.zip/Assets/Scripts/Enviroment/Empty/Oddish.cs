using Pathfinding;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Oddish : Empty
{
    AIPath AI;
    float LookX = 0;
    int KaCheaker;
    bool isKa;
    Vector2 KaCheakVector;
    Vector2 Direction;
    Vector3 position;



    // Start is called before the first frame update
    void Start()
    {
        EmptyType01 = Type.TypeEnum.Poison;
        EmptyType02 = Type.TypeEnum.Grass;
        player = GameObject.FindObjectOfType<PlayerControler>();
        Emptylevel = SetLevel(player.Level, 30);
        EmptyHpForLevel(Emptylevel);
        AtkAbilityPoint = AbilityForLevel(Emptylevel, AtkEmptyPoint);
        SpAAbilityPoint = AbilityForLevel(Emptylevel, SpAEmptyPoint);
        DefAbilityPoint = AbilityForLevel(Emptylevel, DefEmptyPoint);
        SpdAbilityPoint = AbilityForLevel(Emptylevel, SpdEmptyPoint);
        SpeedAbilityPoint = AbilityForLevel(Emptylevel, SpeedEmptyPoint);
        Exp = BaseExp * Emptylevel / 7;


        //��ȡ����Ŀ�� ����������Ŀ�� ���ø���ĳ�ʼx�������FirstX��
        animator = GetComponent<Animator>();
        rigidbody2D = GetComponent<Rigidbody2D>();
        KaCheakVector = rigidbody2D.position;

        transform.GetChild(3).DetachChildren();



    }

    // Update is called once per frame
    void Update()
    {
        ResetPlayer();
        if (isEmptyInfatuationDone) { UpdateInfatuationDmageCDTimer(); }
        if (!isBorn)
        {
            EmptyDie();
            StateMaterialChange();
            UpdateEmptyChangeHP();
        }
    }

    private void FixedUpdate()
    {
        ResetPlayer();
        if (!isBorn)
        {
            EmptyBeKnock();
            if (!isSleepDone && !isCanNotMoveWhenParalysis) {
                animator.SetFloat("Speed", Mathf.Abs(transform.position.x - LookX));
                if (transform.position.x - LookX >= 0) { animator.SetFloat("LookX", 1); }
                else { animator.SetFloat("LookX", 0); }
                LookX = transform.position.x;
            }
        }

    }

    private void OnCollisionStay2D(Collision2D other)
    {
        if (other.transform.tag == ("Player"))
        {
            EmptyTouchHit(other.gameObject);
        }
        if (isEmptyInfatuationDone && other.transform.tag == ("Empty"))
        {
            InfatuationEmptyTouchHit(other.gameObject);
        }
    }

    public void CallCanMove()
    {
        //AI.canMove = true;
        animator.SetFloat("Speed", 1.0f);
    }
}
