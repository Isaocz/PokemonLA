using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossRoom : MonoBehaviour
{

    public GameObject NextFloorDoorUp;
    public GameObject NextFloorDoorDown;
    public GameObject NextFloorDoorLeft;
    public GameObject NextFloorDoorRight;
}
