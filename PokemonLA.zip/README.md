# PokemonLA
![image](https://github.com/Isaocz/PokemonLA/blob/master/Assets/Art/UI/StartPanel/StartPanel.png)
### 重要说明
首次运行请先阅读 [doc/readme](https://github.com/Isaocz/PokemonLA/blob/master/doc/readme.txt) 
